var express = require('express');
var router = express.Router();
var userModel = require('../models/userModel');
const jwt = require('jsonwebtoken');
var bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const secretKey = 'your-secret-key';


const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, 'public', 'images');
    fs.mkdirSync(uploadPath, { recursive: true });
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({ storage: storage });

/* GET home page. */
router.post('/', authenticateToken, upload.single('profileImage'), async function(req, res) {
  try{
    const hashedPassword = await bcrypt.hash(req.body.password, 10);

    let createdUser = await userModel.create({
      username: req.body.userName,
      password: hashedPassword,
      usertype: req.body.userType,
      profileImage: req.file.filename,
    });
    res.send(createdUser);
  } catch(error){
    console.error('Error Creating User : ', error);
    res.status(500).send('Internal Server Error !');
  }
});

router.get('/login', async (req, res) => {
  try{
    console.log(req.body);
    const username = req.body.userName;
    const password = req.body.password;
    const user = await userModel.findOne({username});

    if(!user) {
      return res.status(401).json({error : 'Invalid Username or Password !'});
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const token = jwt.sign({ username : user.username, userId : user._id}, secretKey, { expiresIn : '1h'});

    res.json({ token });

  } catch(error){
    console.error('Error In Log In : ', error);
    res.status(401).send('Login Denied !');
  }
});

router.get('/all', authenticateToken, async (req, res) => {
  try{
    
    const users = await userModel.find();

    if(!users) {
      return res.status(401).json({error : 'Invalid Username or Password !'});
    }

    res.json(users);

  } catch(error){
    console.error('Error In Log In : ', error);
    res.status(401).send('Login Denied !');
  }
});

function authenticateToken(req, res, next) {
  const authorizationHeader = req.headers.authorization;

  if (!authorizationHeader) {
    return res.sendStatus(401);
  }

  // Split the header into an array ["Bearer", "your-token"]
  const [bearerPrefix, token] = authorizationHeader.split(' ');

  if (bearerPrefix !== 'Bearer' || !token) {
    return res.sendStatus(401);
  }

  jwt.verify(token, secretKey, (err, user) => {
    if (err) {
      return res.sendStatus(403);
    }

    req.user = user;
    next();
  });
}



module.exports = router;
