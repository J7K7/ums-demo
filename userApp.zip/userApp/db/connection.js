var mongoose = require('mongoose');

//Connect Mongoose
mongoose.connect(process.env.DBURL);